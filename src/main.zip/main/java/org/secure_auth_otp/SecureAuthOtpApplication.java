package org.secure_auth_otp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecureAuthOtpApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecureAuthOtpApplication.class, args);
    }

}
