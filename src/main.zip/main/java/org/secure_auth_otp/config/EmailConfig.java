package org.secure_auth_otp.config;

public class EmailConfig {
}
